import pandas
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.ensemble import VotingClassifier

url = "https://raw.githubusercontent.com/jbrownlee/Datasets/master/pima-indians-diabetes.data.csv"

names = ['preg', 'plas', 'pres', 'skin', 'test', 'mass', 'pedi', 'age', 'class']
dataframe = pandas.read_csv(url, names=names)
array = dataframe.values

X = array[:,0:8]
Y = array[:,8]

kfold = model_selection.KFold(n_splits=5, shuffle=True, random_state=43)

# modele "składowe"

estimators = []
model1 = LogisticRegression(max_iter=200)
estimators.append(('regression', model1))
model2 = DecisionTreeClassifier()
estimators.append(('cart', model2))
model3 = SVC()
estimators.append(('svm', model3))

ensemble = VotingClassifier(estimators)

results = model_selection.cross_val_score(model1, X, Y, cv=kfold)
print("Wynik LogisticRegression: ", results.mean())

results = model_selection.cross_val_score(model2, X, Y, cv=kfold)
print("Wynik DecisionTreeClassifier: ", results.mean())

results = model_selection.cross_val_score(model3, X, Y, cv=kfold)
print("Wynik SVC: ", results.mean())

results = model_selection.cross_val_score(ensemble, X, Y, cv=kfold)
print("Wynik po złożeniu: ", results.mean())
