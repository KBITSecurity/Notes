#Ogolny import
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split

#Zaladowanie przykladowych danych  ta funkcje trzeba dokleic z innego przyladu
x, y = load_simple_classifier_dataset()

#Podzial danych na dane testowe i dane treningowe w sosunku 80%/20%
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2)


#Tworzymy dwa klasyfikatory (tu drzewa decyzyjne)
clf = DecisionTreeClassifier()
clf_2 = DecisionTreeClassifier()

#Uczymy nasze klasyfikatory (jeden na danych treningowych drugi na calosci)
clf.fit(X_train, y_train)
clf_2.fit(x, y)

#Przewidujemy kolejne wartosci
y_pred = clf.predict(X_test)

#wypisujemy je prawdziwe i przewidziane
print("true values ", y[:10])
print("predicted   ", y_pred[:10])

# Obliczamy odchylenie 1 - super wyszkolony (za mocno), 0 - dal dupy (cos nie tak)
print("scoring...")
clf_score = clf.score(X_train, y_train)

# Wyswietlamy na ile algorytm sie wyszkolil
print("Train score = ", clf_score)
clf_score = clf.score(X_test, y_test)
print("Test score = ", clf_score)

clf_score = clf_2.score(x, y)
print("whole set score = ", clf_score)
