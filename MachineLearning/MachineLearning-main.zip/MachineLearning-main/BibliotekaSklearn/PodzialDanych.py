Ogolnie potrzebujemy dane treningowe, dane do validacji po kazdej epoce i dane do testow.
czesto sie laczy dane validacyjne z danymi do testow ale to niepoprawne.

Wyglada to tak:
x = [1,2,3,4,5,6,7,8,9]
x_train = x[0:7]
x_test = x[7:8]
x_valid = x[8:9]

ale mozemy do tego uzyc funkcji model_selection z sklearn ktora to ulatwia bo czesto jest tak 
ze mamy ciag danych i czesc uczymy i z czesci sprawdzamy.







from sklearn.model_selection import train_test_split
"""
Dane wejściowe:
    X - wejście do naszego modelu, które chcemy podzielić.
        Może to być tablica NumPy, lista Pythona, dataframe z Pandas itp.
    y - true labels, które chcemy podzielić wraz z wejściem.
        Chcemy mieć taki sam podział wejść i odpowiadających im wyjść, prawda?

    test_size    - jaki procent danych ma być użyty do testowania, 0.33 == 33%
    random_state - ustalenie tej wartości gwarantuje zawsze taki sam podział.
                   Przydatne przy porównywaniu klasyfikatorów na tych samych danych

Dane wyjściowe:
    X_train, X_test - wejścia odpowiednio dla treningu i testowania
    y_train, y_test - wyjścia odpowiednio da treningu i testowania odpowiadające
                      kolejnością wejściom (relacja wejście wyjście jest zachowana)
"""

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)
