from sklearn.datasets import make_classification
from sklearn.datasets import fetch_openml

# Prosty zbiór danych dostarczający losowe dane obiektów dwóch klas,
# Aby przerobić na obiekty 3 klas, należy dodać kolejny element listy
# weights, odpowiednio dopasować wagi, tak aby suma wynosiła 1.

"""
    Przykład tworzenia prostego zbioru danych
"""
def load_simple_classifier_dataset(weights=[0.5, 0.5]):
    """
        Metoda generująca prosty zbiór danych

        Argumenty:
            weights - lista z udziałami obiektów każdej klasy w próbce,
                      ich suma musi wynosić 1

        Zwraca:
            X - dane wejściowe dla modelu
            y - true labels dla tych danych wejściowych
    """

    X, y = make_classification(
        n_samples=1000,
        n_classes=len(weights),
        n_informative=len(weights),
        weights=weights,
        flip_y=0,
        random_state=1
    )

    return X, y
