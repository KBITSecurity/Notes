from sklearn.tree import DecisionTreeClassifier # drzewo decyzyjne -> tree
from sklearn.svm import SVC # typ SVM, czyli po kropce jest svm
from sklearn.neighbors import KNeighborsClassifier # model k najbliższych sąsiadów

# stworzenie klasyfikatorów
dt_clf = DecisionTreeClassifier()
svc_clf = SVC()
knn_clf = KNeighborsClassifier()

# stworzenie pełnego pipeline'u ML
x, y = load_simple_classifier_dataset()

# wrzucamy wszystkie klasyfikatory do jednej listy
klasyfikatory = [dt_clf, svc_clf, knn_clf]

for clf in klasyfikatory:
    print("--------------")
    print("fitting - training...")
    clf.fit(x, y)

    print("predicting...")
    y_pred = clf.predict(x)

    # wpisujemy wartości dla pierwszych 10 predykcji

    print("true values ", y[:10])
    print("predicted   ", y_pred[:10])

    print("scoring...")

    clf_score = clf.score(x, y)
    print("score = ", clf_score)
