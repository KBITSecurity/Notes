"""
    Przykład ładowania trudniejszego zbioru danych
"""
def load_mnist_data():
    """
        Zwraca:
            X - dane
            y - target labels
            target_names - labels do tego zbioru
    """
    mnist_data = fetch_openml('mnist_784', version=1)
    print("keys of data dictionary: ", mnist_data.keys())

    X, y = mnist_data['data'], mnist_data['target']

    return X, y, mnist_data.target_names
