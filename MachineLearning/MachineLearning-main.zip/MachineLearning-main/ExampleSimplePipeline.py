# tworzenie zbioru danych
from sklearn.datasets import make_moons
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression



X, y = make_moons(noise=0.3, random_state=0)

# podział danych na treningowe i testowe
X_train, X_test, y_train, y_test = \
    train_test_split(X, y, train_size=.6, random_state=42)
X = StandardScaler().fit_transform(X)


from sklearn.pipeline import Pipeline

clf = Pipeline([('scaler', StandardScaler()), ('clf', LinearRegression())])
clf.fit(X_train, y_train)

print("score dla danych treningowych ZE SKALOWANIEM ", clf.score(X_train, y_train))

**********************************************************************************************************************************************************

from sklearn.preprocessing import PolynomialFeatures

# z zastosowaniem transformacji Polynomial_features
clf = Pipeline([
    ('scaler',StandardScaler()),
    ('poly', PolynomialFeatures(degree=3)), #wielomian stopnia 3
    ('clf', LinearRegression())
])
clf.fit(X_train, y_train)

print("score dla danych treningowych ", clf.score(X_train, y_train))
print("score dla danych testowych ", clf.score(X_test, y_test))

# wykres z granicami decyzyjnymi dla danych treningowych

ax = plot_dataset(X_train, X_test, y_train, y_test, clf=clf, plot_test=False)
plt.tight_layout()
plt.show()

# wykres z granicami decyzyjnymi dla danych testowych

ax = plot_dataset(X_train, X_test, y_train, y_test, clf=clf, plot_train=False)
plt.tight_layout()
plt.show()
