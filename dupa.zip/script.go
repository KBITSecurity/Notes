package main

import (
	"fmt"
	"time"
	"BigEnumerator/wczytanieDanych"
	"BigEnumerator/funkcje"
	"BigEnumerator/fun"
	"strconv"
	"sync"
	"os/exec"
	"os"
)

// TODO zrobic filtrowanie na czas odpowiedzi jak za dlugo to przerwac i notka do pliku cos w stylu comparera tylko ze dal time response
// TODO Max czas enumeracji jednego hosta
// TODO Zrobic aby wykrywal DirectoryListing
// TODO Zrobic tak zeby watki wrzucaly dane do glownego programu jak np. uplynie ponad 3s i jeszcze nic nie wyrzuci
// TODO Zrobic ograniczenie glebokosci enumeracji
// TODO Dorobic aby 404 filtrowalo mimochodem, mechnizm podobny jak do excludeFilter
// TODO Zrobic menu z mozliwoscia zmianiania parametrow i wgrywania dodatkowych wordlist

/////////////////ADMIN/PANEL//////////////////
var iloscWatkow int = 50
var coIlePobracDane int = 10
var extensions []string = []string{}//"html"} //"py", "exe", "html"}
var filtrCode int = 50
var filtrCodeExclude []int = []int{200}
var filtrCodeInclude []int = []int{} //404}
var filtrSize int = 50
var filtrComp int = 50
var filtrCompPercent int = 70
/////////////ZMIENNE/OPTYMALIZACJI/FUNKCJI/FILTROWANIA/////
var filtrOptim int = 0 
var wielkoscFiltru int = 10 // co jak duza zmiane ma uruchomic filtre czyli ile endpointow doszlo
var iloscUruchomienDoWymuszeniaFiltracji int = 500 // co ile ma uruchamiac pomimo braku zmiany
var liczPrzeskoczoneFiltracje int = 0
/////////////////////////////////////////////
///////////////VARIABLE/SHOW/////////////////
var runThreads int = 0
var address string
var perThread int
var komunikat string
var indexEnumeracji int = -1
var dalszaEnumeracja []string
var bledyPodczasEnumeracji []string
var bledyPodczasEnumeracjiLock sync.Mutex
var liczKodyOdpowiedzi map[int]int = make(map[int]int)
var liczSizeOdpowiedzi map[int]int = make(map[int]int)
var liczKodyOdpowiedziLock sync.Mutex
var liczSizeOdpowiedziLock sync.Mutex
var usunietePrzezFiltrCode int = 0
var usunietePrzezFiltrSize int = 0
var usunietePrzezFiltrComp int = 0
var usunietePrzezFiltrLock sync.Mutex
var komunikatOdGlownego string
var maxProgress int64 = 0
var iloscRequestow int = 0
var iloscRequestowOneEndpoint int = 0
var iloscRequestowLock sync.Mutex
var czasEnumeracjiJednegoHosta time.Time
var enumForOneEndpoint int = 0
////////////FOR/FILTER/////////////////////////////
var filtrLiczKodyOdpowiedzi map[int]int = make(map[int]int)
var filtrLiczSizeOdpowiedzi map[int]int = make(map[int]int)
var filtrLiczKodyOdpowiedziLock sync.Mutex
var filtrLiczSizeOdpowiedziLock sync.Mutex
var filtryZapisSzczegolowDoPlikuCode []string
var filtryZapisSzczegolowDoPlikuSize []string
var filtryZapisSzczegolowDoPlikuComp []string
////////////VARIABLE/PROG/////////////////////
var addresses string
var showFinish bool = false
var fullResult []data
var fullResultLock sync.Mutex
var wynik []data // zawiera juz stale na liscie endpointy
var typoweKodyZapis []string
var checkForGetData bool = false
//////FILTRY/DO/ODRZUCANIA/PRZEZ/WATKI////////
var goFiltrCode []int = filtrCodeInclude
var goFiltrSize []int
var goFiltrComp []string
/////////////////////////////////////////////
type data struct {
	url string
	code int
	size int
	body string
}
/////////////////////////////////////////////
func main() {

	// Start programu, i uruchomienie wyswietlania danych na ekranie
	startProgramu := time.Now()
	go show()

	// Wczytanie adresow i wordlisty
	komunikat = "Wczytywanie adresow"
	addresses := wczytanieDanych.Address()
	wordlistMain := wczytanieDanych.Wordlist()

	// Wyliczenie endpointow do enumeracji na jeden endpoint, oraz ilosc na jeden watek
	komunikat = "Wyliczanie endpointow"
	enumForOneEndpoint = int(funkcje.LiczEndpointy(&wordlistMain, int64(len(extensions))))
	perThread = funkcje.LiczEndpointyNaWatek(int(len(wordlistMain)), iloscWatkow)

	// Utworzenie katalogu na wyniki
	komunikat = "Tworzenie katalogu na wyniki"
	os.RemoveAll("./result")
	os.Mkdir("./result", 0755)

	// Pipe dla decyzji watkow i danych z enumeracji
	var decision []chan bool
	var pauze [] chan bool 

	// Petla uruchamiajaca watki
	komunikat = "Uruchamianie watkow"
	for x:=0;x<iloscWatkow;x++ {

		// Opoznienie dla spokojnosci
		//time.Sleep(time.Millisecond * 100)

		// Utworzenie pipe przesylu pauzy i decyzji
		decision = append(decision, make(chan bool))
		pauze = append(pauze, make(chan bool))

		// Porcja wordlisty na watek
		start := perThread*x
		end := perThread*x + perThread

		runThreads++

		// Warunek jezeli jest mala wordlista
		if end >= len(wordlistMain) {
			end = len(wordlistMain)
			go enumeracja(wordlistMain[start:end], start, end, decision[x], pauze[x])
			break
		}
		go enumeracja(wordlistMain[start:end], start, end, decision[x], pauze[x])
	}

	// Uruchomienie funkcji do filtrowania
	go uruchomFiltr()

	// Glowna petla programu
	komunikat = "Enumeracja"
	var addressZapis string = ""
	var addressZapisOriginal string = ""
	var zapisNaKoniecWszystkichWynikowDoAll []string

	for _, x := range addresses {

		// Pobranie czasu / rozpoczecie enumeracji hosta
		czasEnumeracjiJednegoHosta = time.Now()

		// Przypisanie nowego adresu do enumeracji
		komunikat = "Enumeracja web root"
		komunikatOdGlownego = komunikat
		address = x

		// Wyciagniecie z adresu nazwy do zapisania pliku
		addressZapis = funkcje.WyciagnijAddressDoZapisu(address)
		addressZapisOriginal = address

		// Znalezienie typowego kodu i dopisanie do zpisu do pliku i filtrowania jezeli nie jest w wykluczeniach
		typeCode, badUrl, _ := fun.ConnectDefaultCode(address)
		typoweKodyZapis = append(typoweKodyZapis, "+ (Code: " + strconv.Itoa(typeCode) + ") -----> " + badUrl)

		// Wyliczenie maxProgresu
		maxProgress = int64(enumForOneEndpoint)
		
		// Odblokowanie watkow
		for y:=0;y<runThreads;y++ {
			decision[y] <- false
		}

		// Petla rekurencji
		for {
			// Czekanie az wszystkie watki wynumeruja endpoint
			for y:=0;y<runThreads;y++ {
				<-pauze[y]
			}

			////////////////////////DalszaEnumeracja

			// przefiltrowujemy dane do dalszej obrobki
			for y:=0;y<3;y++ {
				filtruj(true)
			}

			// Dodanie dobrych endpointow do wyniku i tych bez BLOCK do dalszej enumeracji
			for y:=0;y<len(fullResult);y++ {

				var czyJuzJest bool = false

				for z:=0;z<len(wynik);z++ {
					if (wynik[z].url == fullResult[y].url) {
						czyJuzJest = true
						break
					}
				}

				if (czyJuzJest == false) {

					wynik = append(wynik, fullResult[y])

					if !(fun.CheckSubString(fullResult[y].url, "{{BLOCK}}")) {
						dalszaEnumeracja = append(dalszaEnumeracja, fullResult[y].url + "/")
					}
				}
			}
			// Wyliczenie maxProgresu
			maxProgress = int64(enumForOneEndpoint) * int64(len(dalszaEnumeracja)+1)

			// Ustalenie dalszej enumeracji albo koniec rekurencji albo wjezdzamy w glab
			indexEnumeracji++
			if (indexEnumeracji >= len(dalszaEnumeracja)) {

				// Zapis do pliku znalezionych endpointow
				var tabZapis []string

				tabZapis = append(tabZapis, "### Address: "+addressZapisOriginal+"\n")
				tabZapis = append(tabZapis, "```List")
				for _,z := range fullResult {
					linia := "+ (Code: " + strconv.Itoa(z.code) + ")"
					linia += fun.WyrownajString(" (Size: " + strconv.Itoa(z.size) + ") ", 22, "-") + "> "
					if (fun.CheckSubString(z.url, "{{BLOCK}}")) {
						linia += z.url[:len(z.url)-9]
					} else {
						linia += z.url
					}
					tabZapis = append(tabZapis, linia)
				}
				tabZapis = append(tabZapis, "```\n")

				// Zapisanie tablicy adktualnych adresu do tablicy z zapisem na koniec do enumeracja-All
				for _,record := range tabZapis {
					zapisNaKoniecWszystkichWynikowDoAll = append(zapisNaKoniecWszystkichWynikowDoAll, record)
				}

				// Dodanie ustawien
				tabZapis = append(tabZapis, "#################################################################")
				tabZapis = append(tabZapis, "################ USTAWIENIA ENUMERACJI ##########################")
				tabZapis = append(tabZapis, "#################################################################")
				tabZapis = append(tabZapis, "----------> iloscWatkow")
				tabZapis = append(tabZapis, "-----> " + strconv.Itoa(runThreads))
				tabZapis = append(tabZapis, "----------> filtrCode")
				tabZapis = append(tabZapis, "-----> " + strconv.Itoa(filtrCode))
				var linia string = ""
				for _,record := range filtrCodeExclude {
					linia += "-"+strconv.Itoa(record)
				}
				tabZapis = append(tabZapis, "-----> " + linia)
				linia = ""
				for _,record := range filtrCodeInclude {
					linia += "+"+strconv.Itoa(record)
				}
				tabZapis = append(tabZapis, "-----> " + linia)
				tabZapis = append(tabZapis, "----------> filtrSize")
				tabZapis = append(tabZapis, "-----> " + strconv.Itoa(filtrSize))
				tabZapis = append(tabZapis, "----------> filtrComparer")
				tabZapis = append(tabZapis, "-----> " + strconv.Itoa(filtrComp))
				tabZapis = append(tabZapis, "-----> " + strconv.Itoa(filtrCompPercent)+"%")
				tabZapis = append(tabZapis, "----------> Czas enumeracji hosta")
				tabZapis = append(tabZapis, "-----> " + time.Since(czasEnumeracjiJednegoHosta).String())

				// Dodanie typowych kodow odpowiedzi
				tabZapis = append(tabZapis, "\n#################################################################")
				tabZapis = append(tabZapis, "---------------> Typowe kody odpowiedzi dla endpointow:")
				tabZapis = append(tabZapis, "#################################################################")
				for _,record := range typoweKodyZapis {
					tabZapis = append(tabZapis, record)
				}

				// Dodanie bledow 
				tabZapis = append(tabZapis, "\n#################################################################")
				tabZapis = append(tabZapis, "---------------> Bledy podczas enumeracji:")
				tabZapis = append(tabZapis, "#################################################################")
				if (len(bledyPodczasEnumeracji) > 0) {
					for _,record := range bledyPodczasEnumeracji {
						tabZapis = append(tabZapis, "---> "+record)
					}
				} else {
					tabZapis = append(tabZapis, "brak")
				}


				// Zapis odpowiedzi ktore zostaly wylapane przez filtry
				// ---> Filtr Code
				tabZapis = append(tabZapis, "\n#################################################################")
				tabZapis = append(tabZapis, "---------------> Wylapane requesty przez filtr Code:")
				tabZapis = append(tabZapis, "#################################################################")
				if (len(filtryZapisSzczegolowDoPlikuCode) > 0) {
					for _,record := range filtryZapisSzczegolowDoPlikuCode {
						tabZapis = append(tabZapis, record+"\n")
					}
				} else {
					tabZapis = append(tabZapis, "Brak wylapan")
				}

				// ---> Filtr Size
				tabZapis = append(tabZapis, "\n#################################################################")
				tabZapis = append(tabZapis, "---------------> Wylapane requesty przez filtr Size:")
				tabZapis = append(tabZapis, "#################################################################")
				if (len(filtryZapisSzczegolowDoPlikuSize) > 0) {
					for _,record := range filtryZapisSzczegolowDoPlikuSize {
						tabZapis = append(tabZapis, record+"\n")
					}
				} else {
					tabZapis = append(tabZapis, "Brak wylapan")
				}

				// ---> Filtr Compare
				tabZapis = append(tabZapis, "\n#################################################################")
				tabZapis = append(tabZapis, "---------------> Wylapane requesty przez filtr Comparer:")
				tabZapis = append(tabZapis, "#################################################################")
				if (len(filtryZapisSzczegolowDoPlikuComp) > 0) {
					for _,record := range filtryZapisSzczegolowDoPlikuComp {
						tabZapis = append(tabZapis, record+"\n")
					}
				} else {
					tabZapis = append(tabZapis, "Brak wylapan")
				}

				// Zapis danych do pliku z szczegolami enumeracji
				fun.SaveFileArray("./result/enumeracja-"+addressZapis, tabZapis)

				break // po break wroci do glownej petli nada nowy adres i zacznie enumerowac
			}

			// Dalsze enumerowanie w glab endpointu
			komunikat = "Enumerowanie rekurencyjne"
			komunikatOdGlownego = komunikat
			address = dalszaEnumeracja[indexEnumeracji]

			// Znalezienie typowego kodu i dopisanie do zpisu do pliku i filtrowania jezeli nie jest w wykluczeniach
			typeCode, badUrl, _ := fun.ConnectDefaultCode(address)
			typoweKodyZapis = append(typoweKodyZapis, "+ (Code: " + strconv.Itoa(typeCode) + ") -----> " + badUrl)
			
			// Wyczyszczenie filtrow i danych dla kolejnego endpointu
			filtrLiczKodyOdpowiedzi = map[int]int{}
			filtrLiczSizeOdpowiedzi = map[int]int{}
			goFiltrCode = filtrCodeInclude
			goFiltrSize = nil
			goFiltrComp = nil
			iloscRequestowOneEndpoint = 0

			// Odblokowanie watkow
			for y:=0;y<runThreads;y++ {
				decision[y] <- false
			}

		} // koniec petli rekurencji

		// Czyszczenie zmiennych dla nowego adresu
		fullResult = nil
		wynik = nil
		dalszaEnumeracja = nil
		indexEnumeracji = -1
		bledyPodczasEnumeracji = nil
		filtryZapisSzczegolowDoPlikuCode = nil
		filtryZapisSzczegolowDoPlikuSize = nil
		filtryZapisSzczegolowDoPlikuComp = nil
		filtrLiczKodyOdpowiedzi = map[int]int{}
		filtrLiczSizeOdpowiedzi = map[int]int{}
		liczKodyOdpowiedzi = map[int]int{}
		liczSizeOdpowiedzi = map[int]int{}
		goFiltrCode = filtrCodeInclude
		goFiltrSize = nil
		goFiltrComp = nil
		usunietePrzezFiltrCode = 0
		usunietePrzezFiltrSize = 0
		usunietePrzezFiltrComp = 0
		typoweKodyZapis = nil
		iloscRequestow = 0

	} // koniec glownej petli programu
	komunikat = "Finishing"

	// Zakonczenie watkow
	for y:=0;y<runThreads;y++ {
		decision[y] <- true
	}

	// Czekanie na zakonczenie kazdego watku 
	for y:=0;y<runThreads;y++ {
		<-decision[y]
	}
	runThreads = 0

	// Zakonczenie show
	time.Sleep(time.Second * 1)
	showFinish = true
	

	// Koniec programu
	czasEnd := time.Since(startProgramu)
	fmt.Println("Czas pracy programu: ", czasEnd)

	// Zapisanie wynikow do enumeracja-All
	fun.SaveFileArray("./result/enumeracja-all", zapisNaKoniecWszystkichWynikowDoAll)
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
func show() {
	var dlugoscLinia int = 100
	var ilePokazywacEndpointow = 15
	var indexPokazania = 0
	var iteracjeRoll = 10 // co ile odswierzac wyswietlane endpointy
	var liczRoll = 0
	var dziejeSie int = 5
	var dziejeSieLicz int = 0
	var progresDzianie int = 0
	var maxZmiany int = 1 // Zmiana max o 1 w wyswietlaniu endpiontow zmienna pomocnicza
	for {
		fun.PrintLinia(dlugoscLinia)
		// Wyswietlanie danych (bardziej statyczne)
		linia := fun.PrintZawiasy("Run threads: " + strconv.Itoa(runThreads) + "/" +  strconv.Itoa(iloscWatkow))
		linia += fun.PrintZawiasy("Endpoints per thread: " + strconv.Itoa(perThread))
		linia += fun.PrintZawiasy("Number of found endpoint: \033[92m" + strconv.Itoa(len(wynik)))
		fmt.Println(linia)

		fun.PrintLinia(dlugoscLinia)

		// Wyswietlanie danych
		linia = "Removed by filter: (Size: "+strconv.Itoa(usunietePrzezFiltrSize)+"), (Code: "
		linia += strconv.Itoa(usunietePrzezFiltrCode)+"), (Comparer: "+strconv.Itoa(usunietePrzezFiltrComp)+")"
		linia = fun.PrintZawiasy(linia)
		fmt.Println(linia)

		// Wyswietlenie progresu
		czasEnumeracji := time.Since(czasEnumeracjiJednegoHosta)
		linia = fun.PrintZawiasy("Progress: " + strconv.Itoa(iloscRequestow) + "/" + strconv.Itoa(int(maxProgress)))
		linia += fun.PrintZawiasy("Time: " + czasEnumeracji.String())
		fmt.Println(linia)

		// Wyswietlanie kodow odpowiedzi
		liczKodyOdpowiedziLock.Lock()
		var kodyShow []int
		var kodyShowAmount []int
		for x,y := range liczKodyOdpowiedzi {
			kodyShow = append(kodyShow, x)
			kodyShowAmount = append(kodyShowAmount, y)
		}
		liczKodyOdpowiedziLock.Unlock()
		for x:=0;x<len(kodyShow);x++ {
			for y:=x+1;y<len(kodyShow);y++ {
				if (kodyShow[x] > kodyShow[y]) {
					tmp := kodyShow[x]
					kodyShow[x] = kodyShow[y]
					kodyShow[y] = tmp

					tmp = kodyShowAmount[x]
					kodyShowAmount[x] = kodyShowAmount[y]
					kodyShowAmount[y] = tmp
				}
			}
		}


		var liniaKody string = "Code response: "
		for x:=0;x<len(kodyShow);x++ {
			liniaKody += "(" + strconv.Itoa(kodyShow[x]) + ": " + strconv.Itoa(kodyShowAmount[x]) + "), "
		}

		if (len(liniaKody) > 2) {
			liniaKody = liniaKody[:len(liniaKody)-2]
		}

		liniaKody = fun.PrintZawiasy(liniaKody)
		endpoZrob := "Enumerate endpoint: \033[96m" + strconv.Itoa(indexEnumeracji+1) + "/" + strconv.Itoa(len(dalszaEnumeracja))
		liniaKody += fun.PrintZawiasy(endpoZrob)
		fmt.Println(liniaKody)

		// Wyswietlanie adresu
		fmt.Println(fun.PrintZawiasy("Address: \033[96m" + address)+fun.PrintZawiasy("\033[35m"+komunikat))


		fun.PrintLinia(dlugoscLinia)
		// Wyswietlenie paska progresu
		showProgres := "\033[91m|"
		showProgres += fun.WyrownajString(fun.GetProgressBar(int(maxProgress), int(iloscRequestow), dlugoscLinia-3, "#") + ">", dlugoscLinia-2, " ")
		showProgres += "|\033[0m"
		fmt.Println(showProgres)
		fun.PrintLinia(dlugoscLinia)
		showProgres = "\033[93m|"
		TshowProgres := fun.GetProgressBar(enumForOneEndpoint, iloscRequestowOneEndpoint, dlugoscLinia-3, "#") + ">"
		showProgres += fun.WyrownajString(TshowProgres, dlugoscLinia-2, " ")
		showProgres += "|\033[0m"
		fmt.Println(showProgres)
		fun.PrintLinia(dlugoscLinia)

		// Wyswietlanie endpointow
		var endpointsToShow []string
		var liczToShow int = 0
		maxZmiany++

		// 3.1 Zapisanie rekordow do wyswietlenia bezposrednio na ekranie do tablicy endpointsToShow
		for _,x := range fullResult {
			liczToShow++
			if (maxZmiany < liczToShow) {
				break 
			}

			var urlShow string = x.url
			if (fun.CheckSubString(x.url, "{{BLOCK}}")) {
				urlShow = x.url[:len(x.url)-9]
			}

			linia := "\033[92m[+]\033[0m " + fun.WyrownajString(strconv.Itoa(liczToShow)+".", 5, " ")
			linia += fun.WyrownajString(urlShow, 64, " ") + " \033[35m(Code: \033[95m" + strconv.Itoa(x.code) + "\033[35m)\033[0m "
			linia += "\033[36m(Size: \033[96m" + strconv.Itoa(x.size) + "\033[36m)\033[0m"

			endpointsToShow = append(endpointsToShow, linia)
		}

		if (maxZmiany > len(fullResult)) {
			maxZmiany = len(fullResult)
		}

		// Uzupelnienie jezeli jest krotka lista tak aby ekran sie nie trzas, byl bardziej statyczny
		for x := len(endpointsToShow)+1; x<=ilePokazywacEndpointow; x++ {
			endpointsToShow = append(endpointsToShow, "\033[32m[+] \033[37m" + strconv.Itoa(x) + ".\033[0m")
		}


		// 3.2 Wyliczenie indexu i opoznienia do wyswietlania
		liczRoll++
		if (liczRoll >= iteracjeRoll) {
			indexPokazania++
			liczRoll = 0
		}
		if (indexPokazania + ilePokazywacEndpointow >= len(endpointsToShow)) {
			indexPokazania = 0
		}
		// 3.3 Wyswietlenie endointow
		for x := indexPokazania; x<indexPokazania + ilePokazywacEndpointow; x++ {
			if (x >= len(endpointsToShow)) {
				indexPokazania = 0
				break
			}
			fmt.Println(endpointsToShow[x])
		}
		

		fun.PrintLinia(dlugoscLinia)
		// Wyswietlenie ze cos sie dzieje
		dziejeSieLicz++
		if (dziejeSieLicz >= dziejeSie) {
			progresDzianie++
			dziejeSieLicz = 0
		}
		linia = "\033[34m"
		for x := 0; x<progresDzianie;x++ {
			linia += "."
		}
		fmt.Println(linia)
		if (progresDzianie+1 >= dlugoscLinia) {
			progresDzianie = 0
		}
		linia += "\033[0m"

		fun.PrintLinia(dlugoscLinia)

                // Wyczyszczenie ekranu
                time.Sleep(time.Millisecond * 99)
                screen := exec.Command("clear")
                screen.Stdout = os.Stdout
                screen.Run()

		if (showFinish) {
			break
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
func enumeracja(wordlist []string, start int, stop int, decision chan bool, pauza chan bool) {

	// Watki uruchamiaja sie zatrzymane
	<-decision
	
	// Zmienne dla adresu w procesie enumeracji
	var url string
	var urlZapis string
	var czyBlock bool

	// Zmienne uzywane w procesie enumeracji
	var powodzeniePolaczenia bool = false
	var code int
	var body string
	var err error
	var lenBody int

	// Zmienne statystyczne
	var liczKody map[int]int = make(map[int]int)
	var liczSize map[int]int = make(map[int]int)

	var liczUsunieteKody int = 0
	var liczUsunieteSize int = 0
	var liczUsunieteComp int = 0

	// Licz probyRequestu / iteracje petli
	var probyRequestu int = 0
	
	// Glowny wynik
	var result []data

	// Glowna petla watku
	for {
		// Petla endpointow
		for x:=0;x<len(wordlist);x++ {
			czyBlock = false
			// Petla rozszerzen
			for _,ext := range append(extensions, "") {

				///////////////////////////////////////////////////////////////////
				/////////////////////////GLOWNA/ENUMERACJA////////////////////////
				probyRequestu++

				// Ustalenie adresu i zapisu do wyniku
				if (fun.CheckSubString(wordlist[x], "{{BLOCK}}")) {
					// Wyjscie z petli jak raz zrobi dla BLOCK
					if (czyBlock) {
						break
					}

					czyBlock = true

					urlZapis = address + wordlist[x]
					url = address + wordlist[x][:len(wordlist[x])-9]
				} else if (ext == "") {
					url = address + wordlist[x]
					urlZapis = url
				} else {
					url = address + wordlist[x] + "." + ext
					urlZapis = url + "{{BLOCK}}"
				}

				// Polaczenie
				powodzeniePolaczenia = false
				for z:=0;z<10;z++ {
					code, body, err = fun.ConnectGetBurpContent(url)
					if err != nil {
						time.Sleep(time.Second)
						bledyPodczasEnumeracjiLock.Lock()
						bledyPodczasEnumeracji = append(bledyPodczasEnumeracji, "Dlugie oczekiwanie polaczenia do adresu ["+url+"]") 
						bledyPodczasEnumeracjiLock.Unlock()
						continue
					}
					powodzeniePolaczenia = true
					break
				}

				// Dopisanie bledu jak cos poszlo nie tak z polaczeniem i jazda dalej
				if (powodzeniePolaczenia == false) {
					bledyPodczasEnumeracjiLock.Lock()
					bledyPodczasEnumeracji = append(bledyPodczasEnumeracji, "Blad polaczenia do adresu ["+url+"]") 
					bledyPodczasEnumeracjiLock.Unlock()
					continue
				}
				lenBody = len(body)

				////////////// Zbieranie statystyki

				liczKody[code] += 1
				liczSize[lenBody] += 1


				// Wyslanie danych statystycznych
				if ((checkForGetData == false) && (probyRequestu >= coIlePobracDane)) {
					checkForGetData = true
					go getData(liczKody, liczSize, result, liczUsunieteKody, liczUsunieteSize, liczUsunieteComp, probyRequestu)
					liczKody = map[int]int{}
					liczSize = map[int]int{}
					liczUsunieteKody = 0
					liczUsunieteSize = 0
					liczUsunieteComp = 0
					result = nil
					probyRequestu = 0
				}

				////////////// FILTROWANIE
				
				if (fun.CheckIsset(goFiltrCode, code)) {
					liczUsunieteKody++
					continue
				}
				if (fun.CheckIsset(goFiltrSize, lenBody)) {
					liczUsunieteSize++
					continue
				}

				if (len(goFiltrComp) > 0) {
					var czyZnalazloZlyContent bool = false
					for _,z := range goFiltrComp {
						if (fun.CompareString(body, z) >= filtrCompPercent) {
							czyZnalazloZlyContent = true
							break
						}
					}
					if (czyZnalazloZlyContent) {
						liczUsunieteComp++
						continue
					}
				}

				// Zapisanie glownego wyniku
				result = append(result, data{urlZapis, code, lenBody, body})
				///////////////////////////////////////////////////////////////////
				/////////////////////////GLOWNA/ENUMERACJA/KONIEC//////////////////

			} // koniec petli rozszerzen
		} // koniec petli endpointow

		// Wyslanie reszty danych statystycznych
		for {
			if (checkForGetData == false) {
				break
			}
			time.Sleep(time.Millisecond * 30)
		}
		go getData(liczKody, liczSize, result, liczUsunieteKody, liczUsunieteSize, liczUsunieteComp, probyRequestu)
		checkForGetData = true
		liczKody = map[int]int{}
		liczSize = map[int]int{}
		liczUsunieteKody = 0
		liczUsunieteSize = 0
		liczUsunieteComp = 0
		result = nil
		probyRequestu = 0

		pauza <- true
		if (<-decision) {
			break
		}
	} // koniec glownej petli
	decision <- true
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
func getData(kody map[int]int, size map[int]int, result []data, Ukody int, Usize int, zlyContent int, probyRequestu int) {


	komunikat = "Getting data"
	fullResultLock.Lock()
	for _,x := range result {
		fullResult = append(fullResult, x)
	}
	fullResultLock.Unlock()

	liczKodyOdpowiedziLock.Lock()
	filtrLiczKodyOdpowiedziLock.Lock()
	for x, y := range kody {
		liczKodyOdpowiedzi[x] += y
 		filtrLiczKodyOdpowiedzi[x] += y
	}
	filtrLiczKodyOdpowiedziLock.Unlock()
	liczKodyOdpowiedziLock.Unlock()

	filtrLiczSizeOdpowiedziLock.Lock()
	liczSizeOdpowiedziLock.Lock()
	for x, y := range size {
		liczSizeOdpowiedzi[x] += y
		filtrLiczSizeOdpowiedzi[x] += y
	}
	liczSizeOdpowiedziLock.Unlock()
	filtrLiczSizeOdpowiedziLock.Unlock()

	iloscRequestowLock.Lock()
	iloscRequestow += probyRequestu
	iloscRequestowOneEndpoint += probyRequestu
	iloscRequestowLock.Unlock()

	usunietePrzezFiltrCode += Ukody
	usunietePrzezFiltrSize += Usize
	usunietePrzezFiltrComp += zlyContent

	//filtruj(false)
	komunikat = komunikatOdGlownego
	checkForGetData = false
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
func uruchomFiltr() {
	for {
		time.Sleep(time.Millisecond * 500)
		filtruj(false)
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
func filtruj(force bool) {

	

	//komunikat = "Filtrowanie"
	fullResultLock.Lock()
	usunietePrzezFiltrLock.Lock()
	defer usunietePrzezFiltrLock.Unlock()
	defer fullResultLock.Unlock()

	var tmp []data

	// Optymalise 

	//komunikat = "Filtrowanie1"
	if ((len(fullResult) < filtrOptim+wielkoscFiltru) && (liczPrzeskoczoneFiltracje < iloscUruchomienDoWymuszeniaFiltracji) && force == false) {
		liczPrzeskoczoneFiltracje++
		return
	}

	liczPrzeskoczoneFiltracje = 0
	
	komunikat = "Filtrowanie2"
	// Filtrowanie code i size w jednej petli
	for x:=0;x<len(fullResult);x++ { // Pentla filtrujaca 3 filtry

		komunikat = "Filtrowanie2.1"
		var czyJest bool = false
		for _,y := range wynik {
			if (y.url == fullResult[x].url) {
				czyJest = true
				break
			}
		}
		if (czyJest) {
			// Dodajemy niezaleznie bo jest juz w zmiennej wynik
			tmp = append(tmp, fullResult[x])
			continue
		}

		komunikat = "Filtrowanie2.2"
		if (!(fun.CheckIsset(filtrCodeExclude, fullResult[x].code)) && (filtrLiczKodyOdpowiedzi[fullResult[x].code] >= filtrCode)) {
			usunietePrzezFiltrCode++
			if (!(fun.CheckIsset(goFiltrCode, fullResult[x].code))) {
				goFiltrCode = append(goFiltrCode, fullResult[x].code)

				var urlZapisRaz string = fullResult[x].url
				if (fun.CheckSubString(fullResult[x].url, "{{BLOCK}}")) {
					urlZapisRaz = fullResult[x].url[:len(fullResult[x].url)-9]
				}

				linia := "-----> " + urlZapisRaz+" (Code: "+strconv.Itoa(fullResult[x].code)
				linia += "):"+"\n\n```\n"+fullResult[x].body+"\n```\n"
				filtryZapisSzczegolowDoPlikuCode = append(filtryZapisSzczegolowDoPlikuCode, linia)
			}
			continue
		}
		komunikat = "Filtrowanie2.3"
		if (filtrLiczSizeOdpowiedzi[fullResult[x].size] >= filtrSize) {
			usunietePrzezFiltrSize++
			if (!(fun.CheckIsset(goFiltrSize, fullResult[x].size))) {
				goFiltrSize = append(goFiltrSize, fullResult[x].size)
				
				var urlZapisRaz string = fullResult[x].url
				if (fun.CheckSubString(fullResult[x].url, "{{BLOCK}}")) {
					urlZapisRaz = fullResult[x].url[:len(fullResult[x].url)-9]
				}

				linia := "-----> " + urlZapisRaz+" (Size: "+strconv.Itoa(fullResult[x].size)
				linia += "):\n\n```\n"+fullResult[x].body+"\n```\n"
				filtryZapisSzczegolowDoPlikuSize = append(filtryZapisSzczegolowDoPlikuSize, linia)
			}
			continue
		}


		komunikat = "Filtrowanie2.4"
		////////////////////////COMP-Strart
		if (len(goFiltrComp) > 0) {

			var czyUsunac bool = false

			for y:=0;y<len(goFiltrComp);y++ {
				if (fun.CompareString(fullResult[x].body, goFiltrComp[y]) >= filtrCompPercent) {
					czyUsunac = true
					usunietePrzezFiltrComp++
					break
				}

			}
			if (czyUsunac) {
				continue
			}
		}
		////////////////////////COMP-Koniec


		komunikat = "Filtrowanie2.5"
		// Doda jezeli nie wpadnie w if z continue
		tmp = append(tmp, fullResult[x])

	} // koniec petli filtrujacej 3 filtry

	komunikat = "Filtrowanie3"
	// Jezeli cos jest do usuniecia to robimy to wpierwszej kolejnosci i nie uruchamiamy szukania compare (return)
	if (len(fullResult) != len(tmp)) {
		fullResult = tmp
		return
	}


	komunikat = "Filtrowanie4"
	// Znalezienie filtrow comp
	var liczComp int = 0
	for x:=0;x<int(len(fullResult)/2);x++ {

		// Optymalizacja - jak jest w wynikach to nie musi porownywac
		var czyJestWWynikach bool = false
		for _,y := range wynik {
			if (y.url == fullResult[x].url) {
				czyJestWWynikach = true
				break
			}
		}
		if (czyJestWWynikach) {
			continue
		}

		// Szukanie ilosci wystapien danej strony
		liczComp = 0
		for y:=x+1;y<len(fullResult);y++ {
			if (fun.CompareString(fullResult[x].body, fullResult[y].body) >= filtrCompPercent) {
				liczComp++
			}
		}

		// Zaliczamy do filtrowania jak taka sama strona wystapi wiele razy
		if (liczComp >= filtrComp) {
			goFiltrComp = append(goFiltrComp, fullResult[x].body)

			var urlZapisRaz string = fullResult[x].url
			if (fun.CheckSubString(fullResult[x].url, "{{BLOCK}}")) {
				urlZapisRaz = fullResult[x].url[:len(fullResult[x].url)-9]
			}

			linia := "-----> " + urlZapisRaz + "\n\n```\n"+fullResult[x].body+"\n```\n"
			filtryZapisSzczegolowDoPlikuComp = append(filtryZapisSzczegolowDoPlikuComp, linia)
			break
		}
	}

	komunikat = "Filtrowanie5"
	// Zapisanie wielkosc tablicy fullRsult do filtru optymalizacynego
	filtrOptim = len(fullResult)

}
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
