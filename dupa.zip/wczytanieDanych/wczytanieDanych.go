package wczytanieDanych

import (
	"BigEnumerator/fun"
)

func Address() []string {
        addresses, err := fun.ReadFileToArray("./address")
        if err != nil {
                panic("Error read address")
        }
	return addresses
}

func Wordlist() []string {

        wordlist, err := fun.ReadFileToArray("./wordlist")
        if err != nil {
                panic("Error read wordlist")
	}

	wordlistBlock, err := fun.ReadFileToArray("./wordlistBlock")
        if err != nil {
                panic("Error read wordlist BLOCK")
        } 

	for _,x := range wordlistBlock {
		wordlist = append(wordlist, x+"{{BLOCK}}")
	}

	return wordlist
}

