package funkcje

import (
	"BigEnumerator/fun"
	"math"
	"strings"
)

func LiczEndpointy(wordlist *[]string, lenExtensions int64) int64 {

	var pojedyncze, podwojne int64
	for _,x := range *wordlist {
		if (fun.CheckSubString(x, "{{BLOCK}}")) {
			pojedyncze++
		} else {
			podwojne++
		}
	}
	podwojne = podwojne * (lenExtensions+1)
	return podwojne + pojedyncze
}

func LiczEndpointyNaWatek(lenWordlist int, threads int) int {
	return  int(math.Ceil(float64(lenWordlist)/float64(threads)))
}

func WyciagnijAddressDoZapisu(adres string) string {

	var result string = fun.LosString(20)

	if (fun.CheckSubString(adres, "//")) {
                result = strings.Split(adres, "//")[1]
	}

	if (fun.CheckSubString(result, "/")) {
		result = strings.Split(result, "/")[0]
	}

	return result


}
