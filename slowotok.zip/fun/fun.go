package fun

import (
	"math"
	"strings"
	"fmt"
	"os"
	"io/ioutil"
	"crypto/tls"
	"net/http"
	"math/rand"
)

// Zwraca losowy ciag znakow w stringu za malych i wielkich liter i cyfr
func LosString(length int) string {
	var los string
	for x := 0;x<(int(length/3)+1);x++ {
		los += string(rand.Intn(10)+48) + string(rand.Intn(25)+65) + string(rand.Intn(25)+97)
	}
	return los[:length]
}

// Funkcja porownuje dwa stringi i zwraca procentowo jak sa podobne (0-100)
func CompareString(string1 string, string2 string) int {

        var long []string
        var short []string
        //var tabBool [] bool

        if len(string1) > len(string2) {
                long = strings.Split(string1, " ")
                short = strings.Split(string2, " ")
        } else {
                long = strings.Split(string2, " ")
                short = strings.Split(string1, " ")
        }

	/*
        for x:=0;x<len(long);x++ {
                tabBool = append(tabBool, false)
        }
	*/


	/*
        var theSameWord int = 0
        for x := 0;x<len(short);x++ {
                for y := 0;y<len(long);y++ {
                        if((long[y] == short[x]) && (tabBool[y] == false)) {
                                tabBool[y] = true
                                theSameWord += 1
                                break
                        }
                }
        }
	*/

        var theSameWord int = 0
        for x := 0;x<len(short);x++ {
                for y := 0;y<len(long);y++ {
                        if (long[y] == short[x]) {
				long[y] = "->|d'" // losowy ciag
                                theSameWord += 1
                                break
                        }
                }
        }

        podobWord := int(math.Ceil((float64(theSameWord)/float64(len(long))) * 100))
	return podobWord
}


///////////////////FUNKCJE/WYSWIETLAJACE///////////////////////
func PrintError(ciag string) {
	fmt.Println("\033[31m[+] \033[0m" + ciag)
}

func PrintOk(ciag string) {
	fmt.Println("\033[32m[+] \033[0m" + ciag)
}

func PrintInfo(ciag string) {
	fmt.Println("\033[33m[+] \033[0m" + ciag)
}

func PrintVuln(ciag string) {
	fmt.Println("\033[34m- \033[0m" + ciag)
}
func PrintLinia(dlugosc int) {
	var linia string = ""
	for x:=0;x<dlugosc;x++ {
		linia += "-"
	}
	fmt.Println("\033[34m"+linia+"\033[0m")
}

func PrintZawiasy(ciag string) string {
	return "\033[34m[\033[94m" + ciag + "\033[34m]\033[0m"
}
// Funkcja wyrownuje ciag do zadanej ilosci ustalonym znakiem
func WyrownajString(napis string, length int, znak string) string {

	var result string = ""
	
	if (len(napis) > length) {
		result = napis[:length-3]
		result += "..."
	} else if (len(napis) < length) {
		result = napis
		for x:=len(napis);x<length;x++ {
			result += znak
		}
	} else {
		result = napis
	}

	return result
}

// Funkcja zapisuje pokejno elementy tablicy jako rekordy do pliku
func SaveFileArray(path string, tab []string) {

	f, err := os.Create(path)
	if (err != nil) {
		panic("Error in saveFile")
	}
	for _,x := range tab {
		f.WriteString(x+"\n")
	}
}

// Funkcja usuwa puste linie z odczytanego pliku i zwraca reszte w postaci tablicy
func ReadFileToArray(path string) ([]string, error) {

	file, err := os.ReadFile(path)
	if err != nil {
		var empty []string
		return empty, err
	}

	lista := strings.Split(string(file), "\n")

	var result []string
	for _, x := range lista {
		if string(x) != "" {
			result = append(result, x)
		}
	}

	return result, nil
}

// Funkcja zwraca content strony jak w burpie Naglowki i Body + kod odpowiedzi
func ConnectGetBurpContent(addr string) (int, string, error) {


	client := &http.Client{
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		} }

	http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true}

	resp, err := client.Get(addr)
	if err != nil {
		return 0, "", err
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return 0, "", err
	}

	var headers string
	for x := range resp.Header {
		headers += x+":"+resp.Header[x][0]+"\n"
	}

	result := headers+"\n"+string(body)
	code := resp.StatusCode
	
	return code, result, nil
}

// Funkcja zwraca defaultowy kod odpowiedzi servera
func ConnectDefaultCode(addr string) (int, string, error) {

	url := addr+LosString(40)
	code, _, _ := ConnectGetBurpContent(url)
	return code, url, nil

	/*
	var returnsCodes []int
	var returnBody []string
	for x := 0; x < 3;x++ {
		code, _, nil := ConnectGetBurpContent(addr+LosString(10))
		if err != nil {
			return 0, err
		}else{
			returnCodes = append(returnCodes, code)
			returnBody = append(returnBody, body)
		}
	}

	for x := 0; x < 3;x++ {
		code, body, err := ConnectGetBurpContent(addr+LosString(20))
		if err != nil {
			return 0, err
		}else{
			returnCodes = append(returnCodes, code)
			returnBody = append(returnBody, body)
		}
	}

	for x := 0; x < 3;x++ {
		code, body, err := ConnectGetBurpContent(addr+LosString(30))
		if err != nil {
			return 0, err
		}else{
			returnCodes = append(returnCodes, code)
			returnBody = append(returnBody, body)
		}
	}

	var dict map[int]int = make(map[int]int, 1)
	for _,x := range returnCodes {
		dict[x] += 1
	}

	var max int = -1
	var toten int = -1
	for y,x := range dict {
		if x > max {
			max = x
			toten = y
		}
	}

	return toten, nil

*/
}

// Funkcja sprawdza czy jeden ciag zawiera sie w innym
func CheckSubString(long string, small string) bool {

	if len(long) < len(small) {
		return false
	}

	result := false
	for x := 0;x<=len(long)-len(small);x++ {
		wynik := true
		for y := 0; y < len(small); y++ {
			if long[x+y] != small[y] {
				wynik = false
				break
			}
		}
		if (wynik) {
			result = wynik
			break
		}

	}

	return result
}

// Funkcja sprawdza czy dany element znajduje sie w taliby intow
func CheckIsset(tab []int, value int) bool {
	for _,x := range tab {
		if (x == value) {
			return true
		}
	}
	return false
}

// Funkcja zwraca pasek dlugosci znakow wedlug podanych wartosci procentowych
func GetProgressBar(max int, value int, lengthBar int, znak string) string {
	if (value == 0) {
		return ""
	}
	progress := math.Floor(float64(float64(100) * float64(value)) / float64(max))

	iloscZnakow := int(math.Floor(float64(lengthBar) * (float64(progress)/float64(100))))
	var result string = ""
	for x:=0;x<iloscZnakow;x++ {
		result += znak
	}

	if (len(result) > lengthBar) {
		result = result[:lengthBar]
	}

	return result
}

func CheckConnect(address string) bool {

	code, _, _ := ConnectGetBurpContent(address)

	if (code == 0) {
		return false
	} else {
		return true
	}
}


// Funkcja doklada znak z obydwustron tak aby bylo po srodku lub swraca strin WARNING_LENGTH
func WyrownajObustronnnie(napis string, dlugosc int, znak string) string {

	if (len(napis) > dlugosc) {
		return "WARNING_LENGTH"
	}
	if (len(napis) == dlugosc) {
		return napis
	}

	liczPrzerwe := int((dlugosc-len(napis))/2)
	var patent string = ""

	for x:=0;x<liczPrzerwe;x++ {
		patent += znak
	}

	var result string = patent + napis + patent

	if (len(result) > dlugosc) {
		result = result[:dlugosc]
	}
	for {
		if (len(result) < dlugosc) {
			result += znak
		} else {
			break
		}
	}

	return result

}







