package main

import (
	"strconv"
	"time"
	"fmt"
	"slowotok/fun"
)

var tablica []string
var dupa int = 0
var slownik []string

var s0 []string
var s1 []string
var s2 []string
var s3 []string
var s4 []string
var s5 []string
var s6 []string
var s7 []string
var sa []string
var sb []string
var sc []string
var sd []string
var se []string
var sf []string
var sg []string
var sh []string
var si []string
var sj []string
var sk []string
var sl []string
var sm []string
var sn []string
var so []string
var sp []string
var sr []string
var ss []string
var st []string
var su []string
var sw []string
var sy []string
var sz []string

var juzSa []string

var Wywolanie int = 0

func sprSlowo(ciag string) {


	if (len(ciag) < 8)  {
		return 
	}

	/*
	for _,x := range juzSa {
		if (x == ciag) {
			return
		}
	}
	*/

// START SLOWNIKI

        if (string(ciag[0]) == "0") {
             for _,x := range s0 {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "1") {
             for _,x := range s1 {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "2") {
             for _,x := range s2 {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "3") {
             for _,x := range s3 {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "4") {
             for _,x := range s4 {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "5") {
             for _,x := range s5 {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "6") {
             for _,x := range s6 {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "7") {
             for _,x := range s7 {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "a") {
             for _,x := range sa {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "b") {
             for _,x := range sb {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "c") {
             for _,x := range sc {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "d") {
             for _,x := range sd {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "e") {
             for _,x := range se {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "f") {
             for _,x := range sf {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "g") {
             for _,x := range sg {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "h") {
             for _,x := range sh {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "i") {
             for _,x := range si {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "j") {
             for _,x := range sj {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "k") {
             for _,x := range sk {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "l") {
             for _,x := range sl {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "m") {
             for _,x := range sm {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "n") {
             for _,x := range sn {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "o") {
             for _,x := range so {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "p") {
             for _,x := range sp {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "r") {
             for _,x := range sr {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "s") {
             for _,x := range ss {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "t") {
             for _,x := range st {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "u") {
             for _,x := range su {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "w") {
             for _,x := range sw {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "y") {
             for _,x := range sy {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }
        if (string(ciag[0]) == "z") {
             for _,x := range sz {
		dupa ++ 
                 if(x == ciag) {
                     fmt.Println(DeConvertPolishCharacters(x))
                     juzSa = append(juzSa, ciag)
                 }
             }
         }


// STOP SLOWNIKI

	/* - stare sprawdzanie calego slownika
	for _,x := range slownik {
		if (x == ciag) {
			fmt.Println(DeConvertPolishCharacters(x))
			juzSa = append(juzSa, ciag)
		}
	} */
}

func szukaj(x int ,y int, slowo string, bylo []string, rula chan bool) {

	dupa++

	if ((x < 0) || (y < 0) || (y > 3) || (x > 3)) {
		return
	}

	var sprBylo string = strconv.Itoa(x) + "x" + strconv.Itoa(y) + "y"
	for _, val := range bylo {
		if (val == sprBylo) {
			return
		}
	}

	bylo = append(bylo, sprBylo)
	for indexX, valX := range tablica {
		var czyKoniec bool = false
		for indexY, valY := range valX {
			if (indexX == x) && (indexY == y) {
				slowo += string(valY)
				czyKoniec = true
				break
			}
		}
		if (czyKoniec) {
			break
		}
	}
	//slowo += string(tablica[y][x])
	
	if (len(slowo) > 11)  {
		return
	}

	start := time.Now()
	sprSlowo(slowo)
	stop := time.Since(start)
	fmt.Println("Czas: ", stop)

	szukaj(x+1, y, slowo, bylo, rula)
	dupa--
	szukaj(x+1, y+1, slowo, bylo, rula)
	dupa++
	szukaj(x, y+1, slowo, bylo, rula)
	dupa--
	szukaj(x-1, y+1, slowo, bylo, rula)
	dupa++
	szukaj(x-1, y, slowo, bylo, rula)
	dupa--
	szukaj(x-1, y-1, slowo, bylo, rula)
	dupa++
	szukaj(x, y-1, slowo, bylo, rula)
	dupa--
	szukaj(x+1, y-1, slowo, bylo, rula)
	dupa++
}

func main() {
	startProgram := time.Now()

	var rula []chan bool 

	//slownik, _ = fun.ReadFileToArray("./slownik")

        s0,_ = fun.ReadFileToArray("0")
        s1,_ = fun.ReadFileToArray("1")
        s2,_ = fun.ReadFileToArray("2")
        s3,_ = fun.ReadFileToArray("3")
        s4,_ = fun.ReadFileToArray("4")
        s5,_ = fun.ReadFileToArray("5")
        s6,_ = fun.ReadFileToArray("6")
        s7,_ = fun.ReadFileToArray("7")
        sa,_ = fun.ReadFileToArray("a")
        sb,_ = fun.ReadFileToArray("b")
        sc,_ = fun.ReadFileToArray("c")
        sd,_ = fun.ReadFileToArray("d")
        se,_ = fun.ReadFileToArray("e")
        sf,_ = fun.ReadFileToArray("f")
        sg,_ = fun.ReadFileToArray("g")
        sh,_ = fun.ReadFileToArray("h")
        si,_ = fun.ReadFileToArray("i")
        sj,_ = fun.ReadFileToArray("j")
        sk,_ = fun.ReadFileToArray("k")
        sl,_ = fun.ReadFileToArray("l")
        sm,_ = fun.ReadFileToArray("m")
        sn,_ = fun.ReadFileToArray("n")
        so,_ = fun.ReadFileToArray("o")
        sp,_ = fun.ReadFileToArray("p")
        sr,_ = fun.ReadFileToArray("r")
        ss,_ = fun.ReadFileToArray("s")
        st,_ = fun.ReadFileToArray("t")
        su,_ = fun.ReadFileToArray("u")
        sw,_ = fun.ReadFileToArray("w")
        sy,_ = fun.ReadFileToArray("y")
        sz,_ = fun.ReadFileToArray("z")

	tablica, _ = fun.ReadFileToArray("./tablica")
	for x:=0;x<len(tablica);x++ {
		tablica[x] = convertPolishCharacters(tablica[x])
	}

	/* - To konwertuje slownik ale slownik jest juz odgornie przekonwertowany
	for x:=0;x<len(slownik);x++ {
		slownik[x] = convertPolishCharacters(slownik[x])
	}*/

	var indexRula int = -1
	for x := 0;x<4;x++ {
		for y := 0;y<4;y++ {
			rula = append(rula, make(chan bool))
			indexRula++
			go szukaj(x, y, "", []string{}, rula[indexRula])
		}
	}

	sprValue := dupa
	for {
		time.Sleep(time.Millisecond * 200)
		if (sprValue == dupa) {
			break
		}
		sprValue = dupa
	}

	endProgram := time.Since(startProgram)
	fmt.Println("Czas Dzialania: ", endProgram)


}



func convertPolishCharacters(ciag string) string {

	var result string = ""

	for _,x := range ciag {
		if ("ą" == string(x)) {
			result += "1"
		} else if ("ć" == string(x)) {
			result += "2"
		} else if ("ę" == string(x)) {
			result += "3"
		} else if ("ł" == string(x)) {
			result += "4"
		} else if ("ż" == string(x)) {
			result += "5"
		} else if ("ś" == string(x)) {
			result += "6"
		} else if ("ó" == string(x)) {
			result += "7"
		} else if ("ń" == string(x)) {
			result += "8"
		} else if ("ź" == string(x)) {
			result += "0"
		} else {
			result += (string(x))
		}
	}

	return result

}

func DeConvertPolishCharacters(ciag string) string {

        var result string = ""

        for _,x := range ciag {
                if ("1" == string(x)) {
                        result += "ą"
                } else if ("2" == string(x)) {
                        result += "ć"
                } else if ("3" == string(x)) {
                        result += "ę"
                } else if ("4" == string(x)) {
                        result += "ł"
                } else if ("5" == string(x)) {
                        result += "ż"
                } else if ("6" == string(x)) {
                        result += "ś"
                } else if ("7" == string(x)) {
                        result += "ó"
                } else if ("8" == string(x)) {
                        result += "ń"
                } else if ("0" == string(x)) {
                        result += "ź"
                } else {
                        result += (string(x))
                }
        }

        return result

}

